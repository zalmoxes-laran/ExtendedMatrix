# EM-blender-tools
Extended Matrix Blender Tools, shortly EMBT, an addon for Blender 3.0
